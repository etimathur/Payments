package com.payment.Transaction_service.service;

import org.springframework.data.jpa.repository.JpaRepository;

import com.payment.Transaction_service.entity.Bills;



public interface Billservice extends JpaRepository<Bills,Long>{

	
	
}
