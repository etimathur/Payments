package com.payment.Transaction_service.service;

import org.springframework.data.jpa.repository.JpaRepository;
import com.payment.Transaction_service.entity.Account_Transaction;

public interface Account_transactionService extends JpaRepository<Account_Transaction,Long> {

}
