package com.payment.Transaction_service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.payment.Transaction_service.entity.Account_Transaction;
import com.payment.Transaction_service.service.Account_transactionService;




@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/Account_transcation")
@RestController
public class Account_transcationController {

private Account_transactionService account_transactionService;
	
	@Autowired
	public void setEmployeeService(Account_transactionService account_transactionService) {
		this.account_transactionService = account_transactionService;
	}
	
	@GetMapping("/")
	public ResponseEntity<List<Account_Transaction>> getAll() {
		return ResponseEntity.ok(account_transactionService.findAll());
	}
	
	@GetMapping("/{Biller_ID}")
	public ResponseEntity<Account_Transaction> findById(@PathVariable Long sequence_Id) {
		return ResponseEntity.ok(account_transactionService.findById(sequence_Id).orElse(null));
	}
	
	@PutMapping("/")
	public ResponseEntity<Account_Transaction> add(@RequestBody Account_Transaction account_transcation) {
		return ResponseEntity.ok(account_transactionService.save(account_transcation));
	}
	
	@PostMapping("/")
	public ResponseEntity<Account_Transaction> update(@RequestBody Account_Transaction account_transcation) {
		return ResponseEntity.ok(account_transactionService.save(account_transcation));
	}

	@DeleteMapping("/{Biller_ID}")
	public ResponseEntity<Account_Transaction> delete(@PathVariable Long sequenceId) {
		account_transactionService.findById(sequenceId).ifPresent(account_transactionService::delete);
		return ResponseEntity.ok().build();
	}

}
