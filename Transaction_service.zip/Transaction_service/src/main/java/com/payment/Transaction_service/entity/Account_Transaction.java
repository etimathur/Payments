package com.payment.Transaction_service.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Account_Transaction {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long SeqId;
	@Column(unique=true)
	private Long TransactionRef;
	@Column
	private Long Date;
	@Column
	private Long Time;
	@Column
	private Long Amount;
	@Column
	private Long Credit;
	@Column
	private Long Debit;
	@Column
    private String Description;
    @Column(unique=true)
    private Long BillRefNum;
    
    
	public Account_Transaction(Long seqId, Long transactionRef, Long date, Long time, Long amount, Long credit,
			Long debit, String description, Long billRefNum) {
		super();
		this.SeqId = seqId;
		this.TransactionRef = transactionRef;
		this.Date = date;
		this.Time = time;
		this.Amount = amount;
		this.Credit = credit;
		this.Debit = debit;
		this.Description = description;
		this.BillRefNum = billRefNum;
	}


	public Long getSeqId() {
		return SeqId;
	}


	public void setSeqId(Long seqId) {
		SeqId = seqId;
	}


	public Long getTransactionRef() {
		return TransactionRef;
	}


	public void setTransactionRef(Long transactionRef) {
		TransactionRef = transactionRef;
	}


	public Long getDate() {
		return Date;
	}


	public void setDate(Long date) {
		Date = date;
	}


	public Long getTime() {
		return Time;
	}


	public void setTime(Long time) {
		Time = time;
	}


	public Long getAmount() {
		return Amount;
	}


	public void setAmount(Long amount) {
		Amount = amount;
	}


	public Long getCredit() {
		return Credit;
	}


	public void setCredit(Long credit) {
		Credit = credit;
	}


	public Long getDebit() {
		return Debit;
	}


	public void setDebit(Long debit) {
		Debit = debit;
	}


	public String getDescription() {
		return Description;
	}


	public void setDescription(String description) {
		Description = description;
	}


	public Long getBillRefNum() {
		return BillRefNum;
	}


	public void setBillRefNum(Long billRefNum) {
		BillRefNum = billRefNum;
	}


	@Override
	public String toString() {
		return "Account_Transaction [SeqId=" + SeqId + ", TransactionRef=" + TransactionRef + ", Date=" + Date
				+ ", Time=" + Time + ", Amount=" + Amount + ", Credit=" + Credit + ", Debit=" + Debit + ", Description="
				+ Description + ", BillRefNum=" + BillRefNum + "]";
	}
    
    

}
