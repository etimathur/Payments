package com.payment.Transaction_service.service;

import org.springframework.data.jpa.repository.JpaRepository;

import com.payment.Transaction_service.entity.Master_bill;

public interface Master_billService extends JpaRepository<Master_bill,Long>{

}
