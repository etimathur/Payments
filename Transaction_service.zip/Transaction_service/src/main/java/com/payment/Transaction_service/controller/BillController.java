package com.payment.Transaction_service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.payment.Transaction_service.entity.Bills;
import com.payment.Transaction_service.service.Billservice;



@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/bills")
@RestController
public class BillController {
	
private Billservice billservice;
	
	@Autowired
	public void setEmployeeService(Billservice billService) {
		this.billservice = billService;
	}
	
	@GetMapping("/")
	public ResponseEntity<List<Bills>> getAll() {
		return ResponseEntity.ok(billservice.findAll());
	}
	
	@GetMapping("/{sequence_Id}")
	public ResponseEntity<Bills> findById(@PathVariable Long sequence_Id) {
		return ResponseEntity.ok(billservice.findById(sequence_Id).orElse(null));
	}
	
	@PutMapping("/")
	public ResponseEntity<Bills> add(@RequestBody Bills bills) {
		return ResponseEntity.ok(billservice.save(bills));
	}
	
	@PostMapping("/")
	public ResponseEntity<Bills> update(@RequestBody Bills bills) {
		return ResponseEntity.ok(billservice.save(bills));
	}

	@DeleteMapping("/{sequence_Id}")
	public ResponseEntity<Bills> delete(@PathVariable Long sequenceId) {
		billservice.findById(sequenceId).ifPresent(billservice::delete);
		return ResponseEntity.ok().build();
	}
}
