// Bill Sequence ID, Biller Code , Consumer Number, Amount, Due Date,status
 

package com.payment.Transaction_service.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Bills {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long Sequence_Id;
	@Column(unique=true)
	private Long Biller_Code;
	@Column
	private Long Consumer_Number;
	@Column
	private Long Amount;
	@Column
	private Long Due_Date;
	@Column
    private String Status;
   

	public Bills(Long sequence_Id, Long biller_Code, Long consumer_Number, Long amount, Long due_Date, String status) {
		super();
		Sequence_Id = sequence_Id;
		Biller_Code = biller_Code;
		Consumer_Number = consumer_Number;
		Amount = amount;
		Due_Date = due_Date;
		Status = status;
	}


	public Long getSequence_Id() {
		return Sequence_Id;
	}


	public void setSequence_Id(Long sequence_Id) {
		Sequence_Id = sequence_Id;
	}


	public Long getBiller_Code() {
		return Biller_Code;
	}


	public void setBiller_Code(Long biller_Code) {
		Biller_Code = biller_Code;
	}


	public Long getConsumer_Number() {
		return Consumer_Number;
	}


	public void setConsumer_Number(Long consumer_Number) {
		Consumer_Number = consumer_Number;
	}


	public Long getAmount() {
		return Amount;
	}


	public void setAmount(Long amount) {
		Amount = amount;
	}


	public Long getDue_Date() {
		return Due_Date;
	}


	public void setDue_Date(Long due_Date) {
		Due_Date = due_Date;
	}


	public String getStatus() {
		return Status;
	}


	public void setStatus(String status) {
		Status = status;
	}


	@Override
	public String toString() {
		return "Bills [Sequence_Id=" + Sequence_Id + ", Biller_Code=" + Biller_Code + ", Consumer_Number="
				+ Consumer_Number + ", Amount=" + Amount + ", Due_Date=" + Due_Date + ", Status=" + Status + "]";
	}



}
