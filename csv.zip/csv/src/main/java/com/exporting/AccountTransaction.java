package com.exporting;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

public class AccountTransaction {
	
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long SequenceId;

	    private Long transactionRef;
	    private String date;
	    private String time;
	    private Long amount;
	    private String type;
	    private String description;
	    private Long billRefNumber;
	    
	    
	    
		public AccountTransaction(Long sequenceId, Long transactionRef, String date, String time, Long amount,
				String type, String description, Long billRefNumber) {
			super();
			SequenceId = sequenceId;
			this.transactionRef = transactionRef;
			this.date = date;
			this.time = time;
			this.amount = amount;
			this.type = type;
			this.description = description;
			this.billRefNumber = billRefNumber;
		}
		public Long getSequenceId() {
			return SequenceId;
		}
		public void setSequenceId(Long sequenceId) {
			SequenceId = sequenceId;
		}
		public Long getTransactionRef() {
			return transactionRef;
		}
		public void setTransactionRef(Long transactionRef) {
			this.transactionRef = transactionRef;
		}
		public String getDate() {
			return date;
		}
		public void setDate(String date) {
			this.date = date;
		}
		public String getTime() {
			return time;
		}
		public void setTime(String time) {
			this.time = time;
		}
		public Long getAmount() {
			return amount;
		}
		public void setAmount(Long amount) {
			this.amount = amount;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public Long getBillRefNumber() {
			return billRefNumber;
		}
		public void setBillRefNumber(Long billRefNumber) {
			this.billRefNumber = billRefNumber;
		}
		
	    
	}

@Repository
public interface AccountTransactionRepository extends JpaRepository<AccountTransaction,Integer> {
}
