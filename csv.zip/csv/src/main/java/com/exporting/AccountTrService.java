package com.exporting;

import java.io.IOException;
import java.io.Writer;
import java.lang.System.Logger;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.springframework.stereotype.Service;

@Service
public class AccountTrService {

   private static final Logger log = getLogger(CsvExportService.class);

    private AccountTransactionRepository accountRepository;


    public void CsvExportService(AccountTransactionRepository employeeRepository, AccountTransactionRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    private static Logger getLogger(Class<com.exporting.CsvExportService> class1) {
		// TODO Auto-generated method stub
		return null;
	}

	public void writeEmployeesToCsv(Writer writer) {

        List<AccountTransaction> accounts = accountRepository.findAll();
        try (CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT)) {
            for (AccountTransaction account : accounts) {
                csvPrinter.printRecord(AccountTransaction.SequenceId(), AccountTransaction.transactionRef(), AccountTransaction.date(), AccountTransaction.time(), AccountTransaction.amount(),AccountTransaction.type(),AccountTransaction.description(),AccountTransaction.billRefNumber());
            }
        } catch (IOException e) {
            log.error("Error While writing CSV ", e);
        }
    }
}