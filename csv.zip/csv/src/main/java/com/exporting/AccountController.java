package com.exporting;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AccountController {

	    private CsvExportService csvExportService = new CsvExportService();

	    public void AccountTransactionController(CsvExportService csvExportService) {
	        this.csvExportService = csvExportService;
	    }

	    @RequestMapping(path = "/accounts")
	    public void getAllEmployeesInCsv(HttpServletResponse servletResponse) throws IOException {
	        servletResponse.setContentType("text/csv");
	        servletResponse.addHeader("Content-Disposition","attachment; filename=\"employees.csv\"");
	        csvExportService.writeAccountsToCsv(servletResponse.getWriter());
	    }

}
