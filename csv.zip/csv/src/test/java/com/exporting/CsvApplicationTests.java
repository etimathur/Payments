package com.exporting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CsvApplicationTests {

	@Test
	void contextLoads() {
	}

}
