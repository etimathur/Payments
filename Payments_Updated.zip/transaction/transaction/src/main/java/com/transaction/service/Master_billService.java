package com.transaction.service;

import org.springframework.data.jpa.repository.JpaRepository;

import com.transaction.entity.Master_bill;



public interface Master_billService extends JpaRepository<Master_bill,Long>{

}
