package com.transaction.service;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.http.ResponseEntity;

import com.transaction.entity.Bill;
import com.transaction.entity.Master_bill;

public interface BillService extends JpaRepository<Bill,Long>{
	
	
	@Query("select p from Bill p where p.status = ?1")
    List<Bill> getPendingBill(String status);
	
	@Query("select p from Bill p where p.billerCode = ?1")
    List<Bill> getSelectedBiller(long billerCode);

}
