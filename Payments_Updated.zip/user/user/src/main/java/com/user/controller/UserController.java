package com.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.user.entity.User;
import com.user.service.UserService;


@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/user")
@RestController
public class UserController {
	
private UserService userServices;
	
	@Autowired
	public void setEmployeeService(UserService userServices) {
		this.userServices = userServices;
	}
	
	@GetMapping("/")
	public ResponseEntity<List<User>> getAll() {
		return ResponseEntity.ok(userServices.findAll());
	}
	
	@GetMapping("/{LoginId}")
	public ResponseEntity<User> findById(@PathVariable Long LoginId) {
		return ResponseEntity.ok(userServices.findById(LoginId).orElse(null));
	}
	
	@PutMapping("/")
	public ResponseEntity<User> add(@RequestBody User user) {
		return ResponseEntity.ok(userServices.save(user));
	}
	
	@PostMapping("/")
	public ResponseEntity<User> update(@RequestBody User user) {
		return ResponseEntity.ok(userServices.save(user));
	}

	@DeleteMapping("/{LoginId}")
	public ResponseEntity<User> delete(@PathVariable Long LoginId) {
		userServices.findById(LoginId).ifPresent(userServices::delete);
		return ResponseEntity.ok().build();
	}

}
