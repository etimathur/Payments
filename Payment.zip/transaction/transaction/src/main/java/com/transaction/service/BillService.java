package com.transaction.service;

import org.springframework.data.jpa.repository.JpaRepository;


import com.transaction.entity.Bill;

public interface BillService extends JpaRepository<Bill,Long>{

}
